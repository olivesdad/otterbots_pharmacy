create definer = andy@`192.168.1.23` view v as
select `l`.`model` AS `model`, `l`.`price` AS `price`
from `product`.`laptop` `l`
union
select `product`.`pc`.`model` AS `model`, `product`.`pc`.`price` AS `price`
from `product`.`pc`
union
select `pr`.`model` AS `model`, `pr`.`price` AS `price`
from `product`.`printer` `pr`;

