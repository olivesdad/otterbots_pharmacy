create definer = andy@`192.168.1.23` view category_region as
select `c`.`categoryid`                      AS `categoryid`,
       `c`.`categoryname`                    AS `categoryname`,
       `r`.`regionid`                        AS `regionid`,
       `r`.`regionname`                      AS `regionname`,
       sum(`zagimore`.`includes`.`quantity`) AS `totalsales`
from (((((`zagimore`.`includes` join `zagimore`.`salestransaction` `s` on (`zagimore`.`includes`.`tid` = `s`.`tid`)) join `zagimore`.`product` `p` on (`zagimore`.`includes`.`productid` = `p`.`productid`)) join `zagimore`.`category` `c` on (`p`.`categoryid` = `c`.`categoryid`)) join `zagimore`.`store` `s2` on (`s`.`storeid` = `s2`.`storeid`))
         join `zagimore`.`region` `r` on (`s2`.`regionid` = `r`.`regionid`))
group by `c`.`categoryid`, `c`.`categoryname`, `r`.`regionid`, `r`.`regionname`;

