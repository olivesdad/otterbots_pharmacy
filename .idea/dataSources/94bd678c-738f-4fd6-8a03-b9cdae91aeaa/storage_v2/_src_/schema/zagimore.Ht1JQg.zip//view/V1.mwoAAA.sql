create definer = andy@`192.168.1.23` view V1 as
select `s`.`tdate`        AS `tdate`,
       `p`.`productid`    AS `productid`,
       `p`.`productname`  AS `productname`,
       `p`.`productprice` AS `productprice`,
       `i`.`quantity`     AS `quantity`,
       `s`.`customerid`   AS `customerid`,
       `c`.`customername` AS `customername`,
       `s`.`storeid`      AS `storeid`,
       `s2`.`storezip`    AS `storezip`,
       `r`.`regionname`   AS `regionname`
from (((((`zagimore`.`product` `p` join `zagimore`.`includes` `i` on (`p`.`productid` = `i`.`productid`)) join `zagimore`.`salestransaction` `s` on (`i`.`tid` = `s`.`tid`)) join `zagimore`.`customer` `c` on (`s`.`customerid` = `c`.`customerid`)) join `zagimore`.`store` `s2` on (`s`.`storeid` = `s2`.`storeid`))
         join `zagimore`.`region` `r` on (`s2`.`regionid` = `r`.`regionid`));

